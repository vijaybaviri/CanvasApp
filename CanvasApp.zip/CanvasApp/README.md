To run the application
-------------------------
First Way
Create a new folder DBnk in C:\ drive and extract the CanvasApp_EXE zipped attachment into C:\DBnk drive
(run.bat file will run by using the command java -jar C:\DBnk\CanvasApp.jar)
Double click run.bat and provide inputs like below
C 20 5
L 1 3 7 3
L 7 1 7 3
R 15 2 20 5

Second Way
Import project into Intellij, run the main java file : DrawCanvas.java

Files Description
----------------------
DrawCanvas - Main Java file of the application
PrepareCanvas - DrawCanvas communicates with this java file
Canvas - This is the file which will be used to draw canvas, line and rectangle as per input parameters

Author - Vijay Bavirisetty
Date -   05072018



